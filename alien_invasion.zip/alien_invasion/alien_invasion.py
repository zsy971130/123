import pygame	 
from settings import Settings
from ship import Ship
from alien import Alien
import game_functions as gf
from pygame.sprite import Group
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard
def run_game():   #
	pygame.init()                                    #初始化背景设置，让pygame能正确的工作（放在所有函数之前）
	ai_settings = Settings()                      #创建一个Settings的 实例 添加到变量ai_settings中
	screen = pygame.display.set_mode(
	(ai_settings.screen_width,ai_settings.screen_height))     #返回屏幕surface对象来创建一个显示窗口，这个实参是元祖，指定了游戏窗口的尺寸
	pygame.display.set_caption("Alien Invasion")    #设置窗口的标题
	play_button = Button(ai_settings,screen,"play")
	stats = GameStats(ai_settings)#创建一个用于存储游戏统计信息的实例
	sb = Scoreboard(ai_settings,screen,stats) #创建记分牌
	ship = Ship(ai_settings,screen)   #创建一艘飞船
	aliens = Group()
	bullets = Group()
	gf.create_fleet(ai_settings,screen,ship,aliens)
	
	
	while True:             #这是事件循环
		gf.check_events(ai_settings,screen,stats,sb,play_button,ship,aliens,bullets)   #检查玩家的输入
		if stats.game_active:
			ship.update()   #更新飞船的位置
			gf.update_bullets(ai_settings,screen,stats,sb,ship,aliens,bullets)  #未消失子弹的位置
			gf.update_aliens(ai_settings,screen,stats,sb,ship,aliens,bullets)
		gf.update_screen(ai_settings,screen,stats,sb,ship,aliens,bullets,play_button)   #刷新屏幕
		
		print(len(bullets))
		print(len(aliens))
		
		
		
run_game()
		
